class Bomb():
    def __init__(self, x, y, stepOfPlacement, bombRange):
        self.x = x
        self.y = y
        self.startStep = stepOfPlacement
        self.bombRange = bombRange
